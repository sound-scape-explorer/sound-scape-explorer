# SSE Docker Web version

This version only allows web visualization, it will not process your audio files

## Requirements

- Docker
- Paste your `features` and `generated` folders inside the main directory

Your project folder should look like this:

```
sse-docker-web
├── features/ <- Paste me
├── generated/ <- Paste me
├── docker-compose.web.yml
├── README.md
├── start.ps1 <- Run me to start the app
└── start-example.png <- Screenshot of what you should get after running `start.ps1`
```

## How to start

Right-click on `start.ps1` then select `Run with PowerShell`